sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ns.ui.bookorder.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);